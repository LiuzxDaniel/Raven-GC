package keystrokesmod.client.utils.profile;

public class UUID {
    public final String uuid;

    public UUID(String id){
        this.uuid = id;
    }
}
