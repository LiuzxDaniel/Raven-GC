package keystrokesmod.client.module.modules.combat;

import keystrokesmod.client.module.*;
import keystrokesmod.client.module.modules.world.AntiBot;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.DoubleSliderSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.CoolDown;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.concurrent.ThreadLocalRandom;

public class STap extends Module {
    public static SliderSetting range, eventType, chance, tapMultiplier, base;
    public static DescriptionSetting eventTypeDesc, cdDesc;
    public static TickSetting onlyPlayers, dynamic, onlyCombo;
    public static DoubleSliderSetting actionTicks, onceEvery, postDelay;
    public static boolean comboing, hitCoolDown, alreadyHit, waitingForPostDelay;
    public static int hitTimeout, hitsWaited;
    public static CoolDown actionTimer = new CoolDown(0), postDelayTimer = new CoolDown(0);

    public STap(){
        super("STap", ModuleCategory.combat);
        this.registerSetting(onlyPlayers = new TickSetting("Only combo players", true));
        this.registerSetting(onlyCombo = new TickSetting("Only comboing", true));
        this.registerSetting(actionTicks = new DoubleSliderSetting("Action Time (MS)",  25, 55, 1, 500, 1));
        this.registerSetting(onceEvery = new DoubleSliderSetting("Once every ... hits", 1, 1, 1, 10, 1));
        this.registerSetting(postDelay = new DoubleSliderSetting("Post Delay (MS)", 10, 40, 0, 500, 1));
        this.registerSetting(chance = new SliderSetting("Chance %", 100, 0, 100, 1));
        this.registerSetting(range = new SliderSetting("Range: ", 3, 1, 6, 0.05));
        this.registerSetting(eventType = new SliderSetting("Value: ", 2, 1, 2, 1));
        this.registerSetting(eventTypeDesc = new DescriptionSetting("Mode: POST"));
        this.registerSetting(dynamic = new TickSetting("Dynamic tap time", false));
        this.registerSetting(base = new SliderSetting("Dynamic tap cooldown base(MS)", 25, 1, 200, 1));
        this.registerSetting(cdDesc = new DescriptionSetting("Too low setting for cooldown base may cause negative cd"));
        this.registerSetting(tapMultiplier = new SliderSetting("Tap time sensitivity", 1F, 0F, 30F, 0.2F));
    }

    public void guiUpdate(){
        eventTypeDesc.setDesc(Utils.md + Utils.Modes.SprintResetTimings.values()[(int) eventType.getInput() - 1]);
    }

    @SubscribeEvent
    public void onTick(TickEvent.RenderTickEvent e) {
        if (!Utils.Player.isPlayerInGame()) return;

        if (waitingForPostDelay && (!onlyCombo.isToggled() || mc.thePlayer.hurtTime == 0)) {
            if (postDelayTimer.hasFinished()) {
                waitingForPostDelay = false;
                comboing = true;
                startCombo();
                actionTimer.start();
            }
            return;
        }

        if (comboing) {
            if (actionTimer.hasFinished()) {
                comboing = false;
                finishCombo();
                return;
            } else {
                return;
            }
        }

        if (mc.objectMouseOver != null && mc.objectMouseOver.entityHit instanceof Entity && Mouse.isButtonDown(0)) {
            Entity target = mc.objectMouseOver.entityHit;
            if (target.isDead) return;

            if (mc.thePlayer.getDistanceToEntity(target) <= range.getInput()) {
                if ((target.hurtResistantTime >= 10 && Utils.Modes.SprintResetTimings.values()[(int) eventType.getInput() - 1] == Utils.Modes.SprintResetTimings.POST)
                        || (target.hurtResistantTime <= 10 && Utils.Modes.SprintResetTimings.values()[(int) eventType.getInput() - 1] == Utils.Modes.SprintResetTimings.PRE)) {

                    if (onlyPlayers.isToggled() && !(target instanceof EntityPlayer)) {
                        return;
                    }

                    if (AntiBot.bot(target)) {
                        return;
                    }

                    if (hitCoolDown && !alreadyHit) {
                        hitsWaited++;
                        if (hitsWaited >= hitTimeout) {
                            hitCoolDown = false;
                            hitsWaited = 0;
                        } else {
                            alreadyHit = true;
                            return;
                        }
                    }

                    if (!(chance.getInput() == 100 || Math.random() <= chance.getInput() / 100)) return;

                    if (!alreadyHit) {
                        guiUpdate();

                        if (onceEvery.getInputMin() == onceEvery.getInputMax()) {
                            hitTimeout = (int) onceEvery.getInputMin();
                        } else {
                            hitTimeout = ThreadLocalRandom.current().nextInt((int) onceEvery.getInputMin(), (int) onceEvery.getInputMax());
                        }

                        hitCoolDown = true;
                        hitsWaited = 0;

                        if (postDelay.getInputMax() != 0) {
                            postDelayTimer.setCooldown((long) ThreadLocalRandom.current().nextDouble(postDelay.getInputMin(), postDelay.getInputMax() + 0.01));
                            postDelayTimer.start();
                            waitingForPostDelay = true;
                        } else if(!onlyCombo.isToggled() || mc.thePlayer.hurtTime == 0){
                            comboing = true;
                            startCombo();
                            actionTimer.start();
                            alreadyHit = true;
                        }

                        alreadyHit = true;
                    }
                } else {
                    if (alreadyHit) {
                        alreadyHit = false;
                    }
                }
            }
        }
    }

    private static void finishCombo() {
        if (!Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode())) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
        }
    }

    private static void startCombo() {
        if (Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode())) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
            KeyBinding.onTick(mc.gameSettings.keyBindForward.getKeyCode());

            if (mc.thePlayer.hurtTime == 0) {
                long cd = (long) base.getInput() + (long) ThreadLocalRandom.current().nextDouble(actionTicks.getInputMin(), actionTicks.getInputMax() + 0.01);
                if (dynamic.isToggled() && mc.objectMouseOver != null && mc.objectMouseOver.entityHit != null) {
                    double dx = mc.thePlayer.posX - mc.thePlayer.prevPosX;
                    double dz = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
                    double speed = Math.sqrt(dx * dx + dz * dz) * 20;
                    Entity target = mc.objectMouseOver.entityHit;
                    double factor = 3.0 - mc.thePlayer.getDistanceToEntity(target);
                    if (factor > 0) {
                        cd -= (factor * tapMultiplier.getInput()) / speed;
                    } else {
                        return;
                    }
                }
                actionTimer.setCooldown((long) cd);
            } else {
                actionTimer.setCooldown((long) ThreadLocalRandom.current().nextDouble(actionTicks.getInputMin(), actionTicks.getInputMax() + 0.01));
            }
        }
    }
}