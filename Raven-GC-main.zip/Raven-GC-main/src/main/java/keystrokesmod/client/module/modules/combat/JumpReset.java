package keystrokesmod.client.module.modules.combat;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import org.lwjgl.input.Mouse;

import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;

public class JumpReset extends Module {
   public static DescriptionSetting desc;
   public static TickSetting tap;
   public static double lastJumpTime = 0;
   public static boolean isJumping = false;

   public JumpReset() {
      super("JumpReset", ModuleCategory.combat);
      this.registerSetting(desc = new DescriptionSetting("Auto jump reset to take less kb."));
      this.registerSetting(tap = new TickSetting("Auto tap when jump", true));
   }

   @SubscribeEvent
   public void onPlayerAttacked(LivingAttackEvent event) {
      if (!Utils.Player.isPlayerInGame())
         return;

      boolean con = false;
      double currentTime = System.currentTimeMillis();
      double cooldownTime = Math.random() * 100 + 300;

      DamageSource source = event.source;

      if (((currentTime - lastJumpTime > cooldownTime) || mc.thePlayer.onGround) && event.entity instanceof EntityPlayer && event.entity == mc.thePlayer && source.getDamageType().equals("player") && !isRangedAttack(source) && !isEnvironmentalDamage(source)) {
         KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), true);
         isJumping = true;
         KeyBinding.onTick(mc.gameSettings.keyBindJump.getKeyCode());
         if (tap.isToggled() && mc.gameSettings.keyBindAttack.isKeyDown() && mc.gameSettings.keyBindForward.isKeyDown()){
            con = true;
         }
         if (con) KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);

         long actionTime = System.currentTimeMillis();
         while (System.currentTimeMillis() - actionTime < (5 + Math.random() * 10)) {
            // wait 5~10ms
         }

         KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
         if (con) KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
         KeyBinding.onTick(mc.gameSettings.keyBindForward.getKeyCode());
         isJumping = false;
      }
   }

   private boolean isRangedAttack(DamageSource source) {
      String type = source.getDamageType();
      return source.isProjectile() || 
             "arrow".equals(type) || 
             "thrown".equals(type) || 
             "indirectMagic".equals(type);
  }

  private boolean isEnvironmentalDamage(DamageSource source) {
      String type = source.getDamageType();
      return source.isFireDamage() || 
             source.isExplosion() || 
             source.isMagicDamage() || 
             "fall".equals(type) ||
             "lava".equals(type) || 
             "inWall".equals(type) || 
             "drown".equals(type);
  }
}
