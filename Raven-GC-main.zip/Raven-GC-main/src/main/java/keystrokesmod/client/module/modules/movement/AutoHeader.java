package keystrokesmod.client.module.modules.movement;

import io.netty.util.internal.ThreadLocalRandom;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import java.util.Random;

public class AutoHeader extends Module {
    public static DescriptionSetting desc;
    public static TickSetting cancelDuringShift, onlyWhenHoldingSpacebar;
    public static SliderSetting pbs;
    private double startWait;

    public AutoHeader() {
        super("AutoHeadHitter", ModuleCategory.movement);
        this.registerSetting(desc = new DescriptionSetting("Spams spacebar when under blocks"));
        this.registerSetting(cancelDuringShift = new TickSetting("Cancel if snkeaing", true));
        this.registerSetting(onlyWhenHoldingSpacebar = new TickSetting("Only when holding jump", true));
        this.registerSetting(pbs = new SliderSetting("Jump Presses per second", 7, 1, 20, 1));

        boolean jumping = false;
    }

    @Override
    public void onEnable(){
        startWait = System.currentTimeMillis();
        super.onEnable();
    }

    @SubscribeEvent
    public void onTick(TickEvent.RenderTickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null)
            return;
        if (cancelDuringShift.isToggled() && mc.thePlayer.isSneaking())
            return;

        if(onlyWhenHoldingSpacebar.isToggled()){
            if(!Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode())){
                return;
            }
        }


        if (Utils.Player.playerUnderBlock() && mc.thePlayer.onGround){
            if(startWait + (1000 / ThreadLocalRandom.current().nextDouble(pbs.getInput() - 0.943543, pbs.getInput() + 1.72748923)) < System.currentTimeMillis()){
                mc.thePlayer.jump();
                startWait = System.currentTimeMillis();
            }
        }

    }
}
