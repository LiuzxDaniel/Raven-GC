package keystrokesmod.client.module.modules.combat;

import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.player.RightClicker;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.module.setting.impl.DoubleSliderSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.modules.world.AntiBot;
import keystrokesmod.client.utils.Utils;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.BlockPos;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockBed;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Mouse;
import net.minecraft.item.*;
import net.minecraft.item.ItemStack;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class AimAssist extends Module {
   public static SliderSetting speed, compliment;
   public static SliderSetting fov;
   public static DoubleSliderSetting distance;
   public static SliderSetting sortMode;
   public static DescriptionSetting sortModeDesc;
   public static TickSetting clickAim;
   public static TickSetting weaponOnly;
   public static TickSetting aimInvis;
   public static TickSetting breakBlocks;
   public static TickSetting blatantMode;
   public static TickSetting ignoreFriends;
   public static TickSetting axeAllowed;
   public static TickSetting breakBed;
   public static TickSetting skipWhenOnTarget;
   public static ArrayList<Entity> friends = new ArrayList<>();

   public AimAssist() {
      super("AimAssist", ModuleCategory.combat);

      this.registerSetting(speed = new SliderSetting("Speed 1", 45.0D, 5.0D, 100.0D, 1.0D));
      this.registerSetting(compliment = new SliderSetting("Speed 2", 15.0D, 2D, 97.0D, 1.0D));
      this.registerSetting(fov = new SliderSetting("FOV", 90.0D, 15.0D, 360.0D, 1.0D));
      this.registerSetting(distance = new DoubleSliderSetting("Distance to player", 0, 3, 0, 6, 0.01));
      this.registerSetting(clickAim = new TickSetting("Click aim", true));
      this.registerSetting(sortMode = new SliderSetting("Value: ", 1, 1, 2, 1));
      this.registerSetting(sortModeDesc = new DescriptionSetting("Sort Mode: 1.Fov; 2. Distance"));
      this.registerSetting(breakBlocks = new TickSetting("Break blocks", false));
      this.registerSetting(breakBed = new TickSetting("Break beds", true));
      this.registerSetting(ignoreFriends = new TickSetting("Ignore Friends", true));
      this.registerSetting(weaponOnly = new TickSetting("Weapon only", true));
      this.registerSetting(axeAllowed = new TickSetting("Allow axe", false));
      this.registerSetting(aimInvis = new TickSetting("Aim invis", false));
      this.registerSetting(blatantMode = new TickSetting("Blatant mode", false));
      this.registerSetting(skipWhenOnTarget = new TickSetting("Skip when on target", true));
   }

   public void update() {

      if (!Utils.Client.currentScreenMinecraft() || !Utils.Player.isPlayerInGame()) {
         return;
      }

      if (breakBlocks.isToggled() && mc.objectMouseOver != null) {
         BlockPos p = mc.objectMouseOver.getBlockPos();
         if (p != null) {
            Block bl = mc.theWorld.getBlockState(p).getBlock();
            if (bl != Blocks.air && !(bl instanceof BlockLiquid) && bl instanceof Block) {
               return;
            }
         }
      }

      if (!weaponOnly.isToggled() || isHoldingWeapon()) {

         Module autoClicker = Raven.moduleManager.getModuleByClazz(RightClicker.class);
         // what if player clicking but mouse not down ????
         if ((clickAim.isToggled() && Utils.Client.autoClickerClicking())
               || (Mouse.isButtonDown(0) && autoClicker != null && !autoClicker.isEnabled()) || !clickAim.isToggled()) {
            Entity en = this.getEnemy();
            if (en != null) {
               // 检查是否跳过瞄准（当准心在敌人上时）
               if (skipWhenOnTarget.isToggled() && isCrosshairOnTarget(en)) {
                  return;
               }
               
               if (Raven.debugger) {
                  Utils.Player.sendMessageToSelf(this.getName() + " &e" + en.getName());
               }

               if (blatantMode.isToggled()) {
                  Utils.Player.aim(en, 0.0F, false);
               } else {
                  double n = Utils.Player.fovFromEntity(en);
                  if (n > 1.0D || n < -1.0D) {
                     double complimentSpeed = n * (ThreadLocalRandom.current()
                           .nextDouble(compliment.getInput() - 1.47328, compliment.getInput() + 2.48293) / 100);
                     double val2 = complimentSpeed
                           + ThreadLocalRandom.current().nextDouble(speed.getInput() - 4.723847, speed.getInput());
                     float val = (float) (-(complimentSpeed + n / (101.0D - (float) ThreadLocalRandom.current()
                           .nextDouble(speed.getInput() - 4.723847, speed.getInput()))));
                     mc.thePlayer.rotationYaw += val;
                  }
               }
            }

         }
      }
   }

   public static boolean isAFriend(Entity entity) {
      if (entity == mc.thePlayer)
         return true;

      for (Entity wut : friends) {
         if (wut.equals(entity))
            return true;
      }
      try {
         EntityPlayer bruhentity = (EntityPlayer) entity;
         if (Raven.debugger) {
            Utils.Player.sendMessageToSelf(
                  "unformatted / " + bruhentity.getDisplayName().getUnformattedText().replace("§", "%"));

            Utils.Player.sendMessageToSelf(
                  "susbstring entity / " + bruhentity.getDisplayName().getUnformattedText().substring(0, 2));
            Utils.Player.sendMessageToSelf(
                  "substring player / " + mc.thePlayer.getDisplayName().getUnformattedText().substring(0, 2));
         }
         if (mc.thePlayer.isOnSameTeam((EntityLivingBase) entity) || mc.thePlayer.getDisplayName().getUnformattedText()
               .startsWith(bruhentity.getDisplayName().getUnformattedText().substring(0, 2)))
            return true;
      } catch (Exception fhwhfhwe) {
         if (Raven.debugger) {
            Utils.Player.sendMessageToSelf(fhwhfhwe.getMessage());
         }
      }

      return false;
   }

   public Entity getEnemy() {
      EntityPlayer bestFov = null;
      EntityPlayer bestDistance = null;
      double minFov = Double.MAX_VALUE;
      double minDist = Double.MAX_VALUE;
  
      int fovLimit = (int) fov.getInput();
  
      for (EntityPlayer en : mc.theWorld.playerEntities) {
         if (en == mc.thePlayer) continue;
         if (en.isDead) continue;
         if (!aimInvis.isToggled() && en.isInvisible()) continue;
         if (ignoreFriends.isToggled() && isAFriend(en)) continue;
         if (AntiBot.bot(en)) continue;
  
         double dist = mc.thePlayer.getDistanceToEntity(en);
         if (dist > distance.getInputMax() || dist < distance.getInputMin()) continue;
  
         if (!blatantMode.isToggled() && !Utils.Player.fov(en, fovLimit)) continue;
  
         if (breakBed.isToggled() && mc.objectMouseOver != null) {
               BlockPos pos = mc.objectMouseOver.getBlockPos();
               if (pos != null) {
                  Block block = mc.theWorld.getBlockState(pos).getBlock();
                  if (block != Blocks.air && !(block instanceof BlockLiquid) && block instanceof BlockBed) {
                     continue;
               }
            }
         }
  
         double yawDiff = Math.abs(((double)(mc.thePlayer.rotationYaw - Utils.Player.fovToEntity(en)) % 360.0D + 540.0D) % 360.0D - 180.0D);
         if (yawDiff < minFov) {
            minFov = yawDiff;
            bestFov = en;
         }
  
         if (dist < minDist) {
            minDist = dist;
            bestDistance = en;
         }
      }
  
      return sortMode.getInput() == 1 ? bestFov : bestDistance;
  }

   public static void addFriend(Entity entityPlayer) {
      friends.add(entityPlayer);
   }

   public static boolean addFriend(String name) {
      boolean found = false;
      for (Entity entity : mc.theWorld.getLoadedEntityList()) {
         if (entity.getName().equalsIgnoreCase(name) || entity.getCustomNameTag().equalsIgnoreCase(name)) {
            if (!isAFriend(entity)) {
               addFriend(entity);
               found = true;
            }
         }
      }

      return found;
   }

   public static boolean removeFriend(String name) {
      boolean removed = false;
      boolean found = false;
      for (NetworkPlayerInfo networkPlayerInfo : new ArrayList<>(mc.getNetHandler().getPlayerInfoMap())) {
         Entity entity = mc.theWorld.getPlayerEntityByName(networkPlayerInfo.getDisplayName().getUnformattedText());
         if (entity.getName().equalsIgnoreCase(name) || entity.getCustomNameTag().equalsIgnoreCase(name)) {
            removed = removeFriend(entity);
            found = true;
         }
      }

      return found && removed;
   }

   public static boolean removeFriend(Entity entityPlayer) {
      try {
         friends.remove(entityPlayer);
      } catch (Exception eeeeee) {
         eeeeee.printStackTrace();
         return false;
      }
      return true;
   }

   public static ArrayList<Entity> getFriends() {
      return friends;
   }

   public static boolean isHoldingWeapon() {
      if (mc.thePlayer.getCurrentEquippedItem()  == null) {
          return false;
      } else {
          ItemStack item = mc.thePlayer.getCurrentEquippedItem(); 
          if (item.getItem() instanceof ItemSword) return true;
          else if (item.getItem() instanceof ItemAxe && !axeAllowed.isToggled())  return true;
          else if (EnchantmentHelper.getEnchantmentLevel(Enchantment.knockback.effectId, item) > 0) return true;
          return false;
      }
  }

   /**
    * 检查玩家准心是否在指定实体上
    * @param entity 要检查的实体
    * @return 如果准心在实体上返回true，否则返回false
    */
   private boolean isCrosshairOnTarget(Entity entity) {
      if (mc.objectMouseOver == null || entity == null) {
         return false;
      }
      
      // 检查鼠标悬停的实体是否是我们瞄准的目标
      if (mc.objectMouseOver.entityHit != null && mc.objectMouseOver.entityHit.equals(entity)) {
         return true;
      }
      
      // 额外的检查：计算玩家到实体的FOV，如果很小说明准心在实体上
      double fovToEntity = Utils.Player.fovFromEntity(entity);
      return Math.abs(fovToEntity) < 2.0D; // 2度的容差
   }
}
