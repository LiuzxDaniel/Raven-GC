package keystrokesmod.client.module.modules.combat;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import keystrokesmod.client.module.modules.combat.JumpReset;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class Velocity extends Module {
   public static SliderSetting a;
   public static SliderSetting b;
   public static SliderSetting c;
   public static SliderSetting waitTime;
   public static TickSetting d;
   public static TickSetting e;
   public static TickSetting onGround;
   public static TickSetting onJumpReset;
   public static double lastJumpTime;

   public Velocity() {
      super("Velocity", ModuleCategory.combat);
      this.registerSetting(a = new SliderSetting("Horizontal", 90.0D, 0.0D, 100.0D, 1.0D));
      this.registerSetting(b = new SliderSetting("Vertical", 100.0D, 0.0D, 100.0D, 1.0D));
      this.registerSetting(c = new SliderSetting("Chance", 100.0D, 0.0D, 100.0D, 1.0D));
      this.registerSetting(d = new TickSetting("Only while targeting", false));
      this.registerSetting(e = new TickSetting("Disable while holding S", true));
      this.registerSetting(onGround = new TickSetting("Only while on ground", true));
      this.registerSetting(onJumpReset = new TickSetting("Only on JumpReset", true));
      this.registerSetting(waitTime = new SliderSetting("Velocity last for JumpReset", 0.0D, 0.0D, 6000.0D, 100.0D));
   }

   @SubscribeEvent
   public void c(LivingUpdateEvent ev) {
      boolean con = false;
      if (!onJumpReset.isToggled() || (JumpReset.isJumping || (System.currentTimeMillis() - lastJumpTime <= waitTime.getInput()))) {
         con = true;
      } else if((!onGround.isToggled() || mc.thePlayer.onGround) && !onJumpReset.isToggled()){
         con = true;
      }
      
      if (Utils.Player.isPlayerInGame() && mc.thePlayer.maxHurtTime > 0 && mc.thePlayer.hurtTime == mc.thePlayer.maxHurtTime && con)
      {
         if(onJumpReset.isToggled()) lastJumpTime = System.currentTimeMillis();

         if (d.isToggled() && (mc.objectMouseOver == null || mc.objectMouseOver.entityHit == null)) {
            return;
         }

         if (e.isToggled() && Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode())) {
            return;
         }

         if (c.getInput() != 100.0D) {
            double ch = Math.random();
            if (ch >= c.getInput() / 100.0D) {
               return;
            }
         }

         if (a.getInput() != 100.0D) {
            mc.thePlayer.motionX *= a.getInput() / 100.0D;
            mc.thePlayer.motionZ *= a.getInput() / 100.0D;
         }

         if (b.getInput() != 100.0D) {
            mc.thePlayer.motionY *= b.getInput() / 100.0D;
         }
      }

   }
}
