/**
package keystrokesmod.client.module.modules.player;

import java.util.*;

import keystrokesmod.client.module.modules.world.AntiBot;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C06PacketPlayerPosLook;
import net.minecraft.util.Vec3;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Category;
import keystrokesmod.client.module.modules.player.AntiBot;
import keystrokesmod.client.setting.SliderSetting;
import keystrokesmod.client.setting.TickSetting;

public class Backtrack extends Module {

    private Minecraft mc = Minecraft.getMinecraft();

    public SliderSetting range = new SliderSetting("Range", 4.0, 0.0, 10.0, 0.1);
    public TickSetting maxLagTicks = new SliderSetting("MaxLagTicks", 10, 0, 100, 1);
    public TickSetting blinkTicksSetting = new SliderSetting("BlinkTicks", 20, 0, 100, 1);
    public TickSetting drawRealPos = new TickSetting("DrawRealPos", true);
    public DescriptionSetting desc = new DescriptionSetting("FakeLag(1)||Blink(2)");
    public TickSetting mode = new SliderSetting("Mode", 1, 1, 2, 1);
    public TickSetting smart = new TickSetting("Smart", true);

    private Map<EntityLivingBase, List<Vec3>> posHistory = new HashMap<>();

    private List<C03PacketPlayer> packetCache = new ArrayList<>();
    private boolean isBlinking = false;
    private boolean isLagging = false;
    private int currentBlinkTick = 0;
    private int currentLagTick = 0;

    public Backtrack() {
        super("Backtrack", Category.PLAYER);
        addSetting(range);
        addSetting(maxLagTicks);
        addSetting(blinkTicksSetting);
        addSetting(mode);
        addSetting(smart);
        addSetting(drawRealPos);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (mc.theWorld == null || mc.thePlayer == null) {
            return;
        }
        boolean enemyInRange = false;
        double actRange = range.getValue();

        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityLivingBase)) continue;
            if (entity == mc.thePlayer) continue;

            EntityLivingBase target = (EntityLivingBase) entity;

            if (AntiBot.bot(target)) continue;
            if (!(target instanceof EntityPlayer)) continue;

            double dist = mc.thePlayer.getDistanceToEntity(target);
            if (dist <= actRange) {
                enemyInRange = true;

                List<Vec3> list = posHistory.get(target);
                if (list == null) {
                    list = new ArrayList<>();
                    posHistory.put(target, list);
                }

                list.add(Vec3.createVectorHelper(target.posX, target.posY, target.posZ));

                if (list.size() > 20) {
                    list.remove(0);
                }
            }
        }

        boolean useFakeLag = (mode.getValue() == 1);
        boolean useBlink = (mode.getValue() == 2);

        if (enemyInRange) {
            if (useFakeLag && !isLagging) {
                isLagging = true;
                currentLagTick = 0;
                packetCache.clear();
            }
            if (useBlink && !isBlinking) {
                isBlinking = true;
                currentBlinkTick = 0;
                packetCache.clear();
            }
        } else {
            if (isLagging) {
                flushFakeLagPackets();
                isLagging = false;
                packetCache.clear();
            }
            if (isBlinking) {
                flushBlinkPackets();
                isBlinking = false;
                packetCache.clear();
            }
        }

        if (isLagging) {
            currentLagTick++;
            if (currentLagTick >= maxLagTicks.getValue()) {
                flushFakeLagPackets();
                currentLagTick = 0;
            }
        }
        if (isBlinking) {
            currentBlinkTick++;
            if (currentBlinkTick >= blinkTicksSetting.getValue()) {
                flushBlinkPackets();
                isBlinking = false;
            }
        }
    }

    public void onPacketSend(Packet<?> packet) {
        if (packet instanceof C03PacketPlayer) {
            C03PacketPlayer c03 = (C03PacketPlayer) packet;
            if (isLagging || isBlinking) {
                packetCache.add(c03);
                // event.setCanceled(true);
            }
        }
    }

    private void flushFakeLagPackets() {
        for (C03PacketPlayer pkt : packetCache) {
            mc.thePlayer.sendQueue.addToSendQueue(pkt);
        }
        packetCache.clear();
    }

    private void flushBlinkPackets() {
        if (packetCache.isEmpty()) return;
        
        C03PacketPlayer lastPkt = packetCache.get(packetCache.size() - 1);
        double finalX = lastPkt.x;
        double finalY = lastPkt.y;
        double finalZ = lastPkt.z;
        float finalYaw = lastPkt.getYaw();
        float finalPitch = lastPkt.getPitch();
        
        if (smart.isToggled()) {
            finalX += (Math.random() - 0.5) * 0.1;
            finalZ += (Math.random() - 0.5) * 0.1;
            finalYaw += (Math.random() - 0.5f) * 2.0f;
            finalPitch += (Math.random() - 0.5f) * 2.0f;
        }
        
        C06PacketPlayerPosLook c06 = new C06PacketPlayerPosLook(
            finalX, finalY, finalZ, finalYaw, finalPitch, lastPkt.isOnGround());
        mc.thePlayer.sendQueue.addToSendQueue(c06);
        packetCache.clear();
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity viewer = mc.getRenderViewEntity();
        if (viewer == null) return;

        float partial = event.getPartialTicks();
        double camX = viewer.lastTickPosX + (viewer.posX - viewer.lastTickPosX) * partial;
        double camY = viewer.lastTickPosY + (viewer.posY - viewer.lastTickPosY) * partial;
        double camZ = viewer.lastTickPosZ + (viewer.posZ - viewer.lastTickPosZ) * partial;

        EntityLivingBase nearestEnt = null;
        C03PacketPlayer nearestPkt = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (Map.Entry<EntityLivingBase, List<C03PacketPlayer>> entry : Backtrack.cachedPackets.entrySet()) {
            EntityLivingBase ent = entry.getKey();
            List<C03PacketPlayer> packets = entry.getValue();
            if (ent.isDead || packets.isEmpty()) continue;

            C03PacketPlayer pkt = packets.get(packets.size() - 1);
            double x = pkt.getPositionX();
            double y = pkt.getPositionY();
            double z = pkt.getPositionZ();
            double dx = x - mc.thePlayer.posX;
            double dy = y - mc.thePlayer.posY;
            double dz = z - mc.thePlayer.posZ;
            double distSq = dx*dx + dy*dy + dz*dz;
            if (distSq < nearestDistSq) {
                nearestDistSq = distSq;
                nearestEnt = ent;
                nearestPkt = pkt;
            }
        }

        if (nearestEnt != null && nearestPkt != null) {

            AxisAlignedBB bb = getBoundingBoxFromPacket(nearestPkt, nearestEnt);

            GlStateManager.pushMatrix();
            GlStateManager.disableTexture2D();
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GlStateManager.disableDepth();

            GL11.glTranslated(-camX, -camY, -camZ);


            Tessellator tess = Tessellator.getInstance();
            WorldRenderer wr = tess.getWorldRenderer();
            wr.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            float r = 1.0f, g = 0f, b = 0f, a = 0.2f;

            wr.pos(bb.minX, bb.minY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.minY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.minY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.minX, bb.minY, bb.maxZ).color(r, g, b, a).endVertex();

            wr.pos(bb.minX, bb.maxY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.minX, bb.maxY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.maxY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.maxY, bb.minZ).color(r, g, b, a).endVertex();

            wr.pos(bb.minX, bb.minY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.minX, bb.maxY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.maxY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.minY, bb.minZ).color(r, g, b, a).endVertex();

            wr.pos(bb.minX, bb.minY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.minY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.maxY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.minX, bb.maxY, bb.maxZ).color(r, g, b, a).endVertex();

            wr.pos(bb.minX, bb.minY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.minX, bb.minY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.minX, bb.maxY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.minX, bb.maxY, bb.minZ).color(r, g, b, a).endVertex();

            wr.pos(bb.maxX, bb.minY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.maxY, bb.minZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.maxY, bb.maxZ).color(r, g, b, a).endVertex();
            wr.pos(bb.maxX, bb.minY, bb.maxZ).color(r, g, b, a).endVertex();
            tess.draw();

            GL11.glLineWidth(2.0F);
            GlStateManager.color(1f, 0f, 0f, 1f);
            RenderGlobal.drawOutlinedBoundingBox(bb, 255, 0, 0, 255); // rgba as ints [oai_citation:4‡skmedix.github.io](https://skmedix.github.io/ForgeJavaDocs/javadoc/forge/1.8.9-11.15.1.2318/net/minecraft/client/renderer/RenderGlobal.html#:~:text=,drawSelectionBoundingBox%20%28%2029%C2%A0p_181561_0)

            GlStateManager.enableDepth();
            GlStateManager.disableBlend();
            GlStateManager.enableTexture2D();
            GlStateManager.popMatrix();
        }
    }

    private static AxisAlignedBB getBoundingBoxFromPacket(C03PacketPlayer packet, EntityLivingBase ent) {
        double x = packet.getPositionX();
        double y = packet.getPositionY();
        double z = packet.getPositionZ();
        double halfW = ent.width / 2.0;
        return new AxisAlignedBB(x - halfW, y, z - halfW, x + halfW, y + ent.height, z + halfW);
    }
}
*/