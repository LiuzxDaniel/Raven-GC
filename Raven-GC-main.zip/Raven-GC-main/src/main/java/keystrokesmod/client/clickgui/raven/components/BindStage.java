package keystrokesmod.client.clickgui.raven.components;

public class BindStage {
   public static String bind = "Bind";
   public static String binding = "Press a key...";
}
