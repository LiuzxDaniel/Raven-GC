Minecraft fields remapped with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using 1.8.9 mappings
